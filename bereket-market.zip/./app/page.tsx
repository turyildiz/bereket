import { FEATURED_SHOPS, LATEST_OFFERS } from './mock-data';
import Link from 'next/link';

// Badge types for variety
const BADGE_TYPES = ['premium', 'new', 'hot'] as const;
type BadgeType = typeof BADGE_TYPES[number];

const getBadgeForShop = (index: number): { type: BadgeType; label: string } => {
  const badges = [
    { type: 'premium' as BadgeType, label: 'Premium Partner' },
    { type: 'new' as BadgeType, label: 'Neu dabei' },
    { type: 'hot' as BadgeType, label: 'Beliebt' },
  ];
  return badges[index % badges.length];
};

export default function Home() {
  return (
    <main className="min-h-screen overflow-hidden">
      {/* Hero Section - Enhanced Split Layout */}
      <section className="relative overflow-hidden border-b-2" style={{ borderColor: 'var(--sand)' }}>
        <div className="mx-auto max-w-7xl">
          <div className="grid lg:grid-cols-2 gap-0">

            {/* Left Column - Content */}
            <div className="relative px-6 py-12 sm:px-10 sm:py-16 lg:py-24 flex flex-col justify-center grain-texture" style={{ background: 'linear-gradient(135deg, var(--cream) 0%, var(--sand) 100%)' }}>
              {/* Decorative Accents */}
              <div className="absolute top-10 right-10 w-40 h-40 opacity-20 blur-3xl animate-float" style={{ background: 'radial-gradient(circle, var(--saffron) 0%, transparent 70%)' }}></div>
              <div className="absolute bottom-20 left-5 w-24 h-24 opacity-15 blur-2xl animate-float" style={{ background: 'radial-gradient(circle, var(--terracotta) 0%, transparent 70%)', animationDelay: '2s' }}></div>

              <div className="relative z-10">
                {/* Enhanced Badge */}
                <div className="inline-block mb-6 animate-fade-in-up">
                  <div
                    className="flex items-center gap-2.5 text-[11px] font-bold tracking-widest uppercase rounded-full px-4 py-2.5 border-2 shadow-lg backdrop-blur-sm hover-scale cursor-default"
                    style={{
                      background: 'rgba(255, 255, 255, 0.9)',
                      borderColor: 'var(--terracotta)',
                      color: 'var(--burgundy)'
                    }}
                  >
                    <span className="relative flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style={{ background: 'var(--terracotta)' }}></span>
                      <span className="relative inline-flex rounded-full h-3 w-3" style={{ background: 'var(--terracotta)' }}></span>
                    </span>
                    KI-gestützt
                  </div>
                </div>

                <h1
                  className="text-4xl sm:text-5xl lg:text-[3.5rem] font-black tracking-tight leading-[1.08] mb-6 animate-fade-in-up"
                  style={{
                    fontFamily: 'var(--font-playfair)',
                    color: 'var(--charcoal)',
                    animationDelay: '0.1s'
                  }}
                >
                  Lokale Märkte,<br />
                  <span className="relative inline-block">
                    <span className="text-gradient-spice relative z-10">
                      frische Deals
                    </span>
                    <svg className="absolute -bottom-1 left-0 w-full h-4 opacity-50" viewBox="0 0 300 12" preserveAspectRatio="none">
                      <path d="M0,6 Q75,0 150,6 T300,6" fill="none" stroke="var(--terracotta)" strokeWidth="8" strokeLinecap="round" />
                    </svg>
                  </span>
                </h1>

                <p
                  className="text-base sm:text-lg leading-relaxed mb-8 max-w-md animate-fade-in-up"
                  style={{
                    color: 'var(--warm-gray)',
                    animationDelay: '0.2s'
                  }}
                >
                  WhatsApp-Foto senden → KI erkennt Angebote → Kunden entdecken täglich neue Deals von türkischen, iranischen, afghanischen & marokkanischen Shops.
                </p>

                <div className="flex flex-col sm:flex-row gap-3 mb-8 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
                  <button
                    className="btn-primary group relative px-8 py-4 font-bold rounded-xl overflow-hidden shadow-lg text-white flex items-center justify-center gap-2"
                  >
                    <span className="relative z-10 flex items-center justify-center gap-2">
                      Jetzt starten
                      <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                      </svg>
                    </span>
                  </button>
                  <button
                    className="px-8 py-4 border-2 font-bold rounded-xl transition-all backdrop-blur-sm btn-outlined-hover flex items-center justify-center gap-2"
                    style={{
                      borderColor: 'var(--charcoal)',
                      color: 'var(--charcoal)',
                      background: 'rgba(255, 255, 255, 0.6)'
                    }}
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    Märkte ansehen
                  </button>
                </div>

                {/* Trust Indicators */}
                <div className="flex items-center gap-4 text-sm animate-fade-in-up" style={{ color: 'var(--warm-gray)', animationDelay: '0.4s' }}>
                  <div className="flex -space-x-3">
                    {[0, 1, 2, 3].map((i) => (
                      <div
                        key={i}
                        className="w-9 h-9 rounded-full border-2 border-white shadow-md flex items-center justify-center text-xs font-bold text-white"
                        style={{
                          background: `linear-gradient(135deg, ${['var(--saffron)', 'var(--terracotta)', 'var(--cardamom)', 'var(--burgundy)'][i]} 0%, ${['var(--terracotta)', 'var(--burgundy)', 'var(--burgundy-dark)', 'var(--terracotta)'][i]} 100%)`
                        }}
                      >
                        {['YM', 'BF', 'AA', 'SM'][i]}
                      </div>
                    ))}
                  </div>
                  <div>
                    <span className="font-bold" style={{ color: 'var(--charcoal)' }}>50+ Märkte</span> in Frankfurt, Berlin & mehr
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Visual */}
            <div className="relative h-[420px] lg:h-auto min-h-[520px] overflow-hidden" style={{ background: 'var(--gradient-night)' }}>
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-8">
                <div className="absolute inset-0 dot-pattern" style={{ opacity: 0.15 }}></div>
              </div>

              {/* Rotating Decorative Element */}
              <div className="absolute top-10 left-10 w-32 h-32 rounded-full border-2 opacity-20 animate-rotate-slow" style={{ borderColor: 'var(--saffron)' }}></div>

              {/* Floating Images */}
              <div className="absolute inset-0 flex items-center justify-center p-8">
                <div className="relative w-full max-w-md">
                  {/* Main Image Card */}
                  <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl transform rotate-2 hover:rotate-0 transition-all duration-500 hover:scale-105 hover-glow">
                    <img
                      src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=800"
                      alt="Fresh Market Produce"
                      className="w-full h-80 object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
                    <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                      <div
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold mb-3 shadow-lg animate-bounce-subtle"
                        style={{ background: 'var(--gradient-warm)' }}
                      >
                        <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
                        LIVE ANGEBOT
                      </div>
                      <p className="text-lg font-bold" style={{ fontFamily: 'var(--font-playfair)' }}>Frische Bio-Tomaten 2.99€/kg</p>
                    </div>
                  </div>

                  {/* Secondary Floating Card */}
                  <div className="absolute -bottom-6 -right-6 w-52 h-36 bg-white rounded-2xl shadow-2xl transform -rotate-6 overflow-hidden border-4 border-white hover:rotate-0 transition-transform duration-500">
                    <img
                      src="https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&q=80&w=400"
                      alt="Spices"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-2 left-2 badge-new">Neu</div>
                  </div>

                  {/* WhatsApp Floating Card */}
                  <div className="absolute -top-4 -left-4 glass-card px-4 py-3 shadow-xl animate-float">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#25D366' }}>
                        <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                        </svg>
                      </div>
                      <div>
                        <p className="text-xs font-bold" style={{ color: 'var(--charcoal)' }}>Foto gesendet</p>
                        <p className="text-xs" style={{ color: 'var(--warm-gray)' }}>KI analysiert...</p>
                      </div>
                    </div>
                  </div>

                  {/* Accent Blob */}
                  <div className="absolute -top-8 -left-8 w-32 h-32 blur-3xl opacity-50 animate-float" style={{ background: 'radial-gradient(circle, var(--saffron), var(--terracotta))', animationDelay: '1s' }}></div>
                </div>
              </div>

              {/* Stats Overlay */}
              <div className="absolute bottom-6 left-6 right-6 flex gap-4">
                <div className="flex-1 glass-card p-4 shadow-xl hover-scale cursor-default" style={{ background: 'rgba(255, 255, 255, 0.15)', border: '1px solid rgba(255, 255, 255, 0.25)' }}>
                  <div className="text-3xl font-black text-white" style={{ fontFamily: 'var(--font-playfair)' }}>247</div>
                  <div className="text-xs text-white/80 font-semibold">Angebote heute</div>
                </div>
                <div className="flex-1 glass-card p-4 shadow-xl hover-scale cursor-default" style={{ background: 'rgba(255, 255, 255, 0.15)', border: '1px solid rgba(255, 255, 255, 0.25)' }}>
                  <div className="text-3xl font-black text-white" style={{ fontFamily: 'var(--font-playfair)' }}>50+</div>
                  <div className="text-xs text-white/80 font-semibold">Partner-Shops</div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* How It Works Section - NEW */}
      <section className="relative py-20 sm:py-28 overflow-hidden" style={{ background: 'white' }}>
        {/* Decorative Elements */}
        <div className="absolute top-0 left-0 w-72 h-72 opacity-10 blur-3xl" style={{ background: 'var(--cardamom)' }}></div>
        <div className="absolute bottom-0 right-0 w-72 h-72 opacity-10 blur-3xl" style={{ background: 'var(--saffron)' }}></div>

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6" style={{ background: 'var(--cream)', color: 'var(--warm-gray)' }}>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              <span className="text-sm font-bold">So einfach funktioniert&apos;s</span>
            </div>
            <h2
              className="text-4xl sm:text-5xl font-black tracking-tight mb-4"
              style={{ fontFamily: 'var(--font-playfair)', color: 'var(--charcoal)' }}
            >
              In 3 Schritten zu<br />
              <span className="text-gradient-warm">frischen Deals</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
            {[
              {
                step: '01',
                icon: '📸',
                title: 'Foto senden',
                description: 'Shop-Besitzer senden einfach ein Foto ihrer aktuellen Angebotstafel per WhatsApp.',
                gradient: 'var(--gradient-warm)'
              },
              {
                step: '02',
                icon: '🤖',
                title: 'KI analysiert',
                description: 'Unsere KI erkennt automatisch Produkte, Preise und erstellt ansprechende Listings.',
                gradient: 'var(--gradient-fresh)'
              },
              {
                step: '03',
                icon: '🛒',
                title: 'Kunden entdecken',
                description: 'Kunden finden sofort die besten Deals in ihrer Nähe und sparen Zeit & Geld.',
                gradient: 'var(--gradient-spice)'
              }
            ].map((item, idx) => (
              <div
                key={item.step}
                className="relative group animate-fade-in-up"
                style={{ animationDelay: `${idx * 0.15}s` }}
              >
                <div className="relative bg-white rounded-3xl p-8 shadow-lg hover-lift border-2 h-full" style={{ borderColor: 'var(--sand)' }}>
                  {/* Step Number */}
                  <div
                    className="absolute -top-4 -left-4 w-12 h-12 rounded-2xl flex items-center justify-center text-sm font-black text-white shadow-lg"
                    style={{ background: item.gradient }}
                  >
                    {item.step}
                  </div>

                  {/* Icon */}
                  <div className="text-5xl mb-6 group-hover:animate-bounce-subtle">{item.icon}</div>

                  <h3
                    className="text-2xl font-bold mb-3"
                    style={{ fontFamily: 'var(--font-playfair)', color: 'var(--charcoal)' }}
                  >
                    {item.title}
                  </h3>
                  <p className="leading-relaxed" style={{ color: 'var(--warm-gray)' }}>
                    {item.description}
                  </p>

                  {/* Connector Line (except last) */}
                  {idx < 2 && (
                    <div className="hidden md:block absolute top-1/2 -right-6 lg:-right-8 w-8 lg:w-12 h-0.5" style={{ background: 'var(--sand)' }}></div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Shops Section - Enhanced */}
      <section className="relative mx-auto max-w-7xl px-4 py-20 sm:py-28 sm:px-6 lg:px-8">
        <div className="mb-16 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4" style={{ background: 'var(--cream)', color: 'var(--warm-gray)' }}>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
              </svg>
              <span className="text-sm font-bold">Handverlesen</span>
            </div>
            <h2
              className="text-4xl sm:text-5xl font-black tracking-tight mb-4"
              style={{ fontFamily: 'var(--font-playfair)', color: 'var(--charcoal)' }}
            >
              Empfohlene Shops
            </h2>
            <p className="text-lg sm:text-xl" style={{ color: 'var(--warm-gray)' }}>
              Die beliebtesten Märkte in deiner Region.
            </p>
          </div>
          <Link
            href="/shops"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all hover:gap-4"
            style={{ background: 'var(--charcoal)', color: 'white' }}
          >
            Alle ansehen
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        </div>

        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURED_SHOPS.slice(0, 6).map((shop, idx) => {
            const badge = getBadgeForShop(idx);
            return (
              <Link
                href={`/shop/${shop.id}`}
                key={shop.id}
                className="group relative rounded-3xl overflow-hidden hover-lift cursor-pointer block animate-scale-in"
                style={{
                  animationDelay: `${idx * 0.1}s`,
                  background: 'white',
                  boxShadow: '0 4px 25px rgba(0, 0, 0, 0.08)'
                }}
              >
                {/* Image Container */}
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={shop.image}
                    alt={shop.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  {/* Overlay Gradient */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>

                  {/* Badge - Varied */}
                  <div className={`absolute top-5 right-5 badge-${badge.type}`}>
                    {badge.label}
                  </div>

                  {/* Shop Name Overlay */}
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <h3
                      className="font-black text-2xl text-white mb-1"
                      style={{ fontFamily: 'var(--font-playfair)' }}
                    >
                      {shop.name}
                    </h3>
                    <p className="text-white/90 font-medium flex items-center gap-2">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                      {shop.branch}
                    </p>
                  </div>
                </div>

                {/* Hover Arrow */}
                <div className="absolute bottom-6 right-6 w-12 h-12 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-4 group-hover:translate-y-0 shadow-lg" style={{ background: 'var(--gradient-warm)' }}>
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
                  </svg>
                </div>

                {/* Decorative Corner */}
                <div
                  className="absolute top-0 left-0 w-28 h-28 opacity-20 rounded-br-full transition-opacity group-hover:opacity-40"
                  style={{ background: 'var(--gradient-warm)' }}
                ></div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Latest Offers Section - Enhanced */}
      <section
        className="relative py-20 sm:py-28 overflow-hidden grain-texture"
        style={{ background: 'linear-gradient(180deg, var(--cream) 0%, #F4E4D7 100%)' }}
      >
        {/* Decorative Background */}
        <div className="absolute top-20 right-0 w-96 h-96 opacity-10 blur-3xl animate-float" style={{ background: 'var(--saffron)' }}></div>
        <div className="absolute bottom-20 left-0 w-96 h-96 opacity-10 blur-3xl animate-float" style={{ background: 'var(--terracotta)', animationDelay: '3s' }}></div>

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div className="text-center md:text-left">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4" style={{ background: 'white', color: 'var(--terracotta)' }}>
                <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: 'var(--terracotta)' }}></span>
                <span className="text-sm font-bold">Live-Updates</span>
              </div>
              <h2
                className="text-4xl sm:text-5xl font-black tracking-tight mb-4"
                style={{ fontFamily: 'var(--font-playfair)', color: 'var(--charcoal)' }}
              >
                Neueste Angebote
              </h2>
              <p className="text-lg sm:text-xl" style={{ color: 'var(--warm-gray)' }}>
                KI-erkannte Deals, frisch für dich.
              </p>
            </div>
            <div className="flex flex-wrap justify-center md:justify-end gap-3">
              <select
                className="rounded-2xl px-5 py-3 text-sm font-bold focus:outline-none cursor-pointer shadow-lg hover-scale"
                style={{
                  background: 'white',
                  color: 'var(--charcoal)',
                  border: '2px solid var(--sand)'
                }}
              >
                <option>🗺️ Alle Städte</option>
                <option>📍 Frankfurt</option>
                <option>📍 Berlin</option>
                <option>📍 München</option>
              </select>
              <select
                className="rounded-2xl px-5 py-3 text-sm font-bold focus:outline-none cursor-pointer shadow-lg hover-scale"
                style={{
                  background: 'white',
                  color: 'var(--charcoal)',
                  border: '2px solid var(--sand)'
                }}
              >
                <option>🏷️ Alle Kategorien</option>
                <option>🥬 Gemüse</option>
                <option>🍖 Fleisch</option>
                <option>🧀 Milchprodukte</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {LATEST_OFFERS.slice(0, 6).map((offer, idx) => (
              <div
                key={offer.id}
                className="group relative rounded-3xl overflow-hidden cursor-pointer hover-lift animate-scale-in"
                style={{
                  background: 'white',
                  boxShadow: '0 4px 25px rgba(0, 0, 0, 0.08)',
                  animationDelay: `${idx * 0.05}s`
                }}
              >
                {/* Image */}
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={offer.image}
                    alt={offer.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  {/* Price Badge */}
                  <div
                    className="absolute top-5 left-5 z-10 px-5 py-2.5 rounded-2xl font-black text-xl text-white shadow-xl"
                    style={{ background: 'var(--gradient-warm)' }}
                  >
                    {offer.price}
                  </div>

                  {/* Category Tag */}
                  <div className="absolute top-5 right-5 px-3 py-1.5 rounded-full text-xs font-bold backdrop-blur-sm" style={{ background: 'rgba(255, 255, 255, 0.9)', color: 'var(--charcoal)' }}>
                    Fresh
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3
                    className="font-bold text-xl mb-2"
                    style={{
                      fontFamily: 'var(--font-playfair)',
                      color: 'var(--charcoal)'
                    }}
                  >
                    {offer.name}
                  </h3>

                  {/* Footer */}
                  <div
                    className="flex items-center justify-between pt-4 border-t"
                    style={{ borderColor: 'var(--sand)' }}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ background: 'var(--gradient-warm)' }}>
                        {offer.market.charAt(0)}
                      </div>
                      <span className="text-sm font-semibold" style={{ color: 'var(--warm-gray)' }}>
                        {offer.market}
                      </span>
                    </div>
                    <span
                      className="text-sm font-bold group-hover:translate-x-2 transition-transform flex items-center gap-1"
                      style={{ color: 'var(--terracotta)' }}
                    >
                      Details
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <path d="M6 3L11 8L6 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                      </svg>
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Load More Button */}
          <div className="mt-16 text-center">
            <button
              className="inline-flex items-center gap-3 px-8 py-4 rounded-2xl font-bold text-lg shadow-xl hover:shadow-2xl hover:scale-105 transition-all"
              style={{
                background: 'var(--gradient-warm)',
                color: 'white'
              }}
            >
              Mehr Angebote laden
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
          </div>
        </div>
      </section>

      {/* CTA Section - NEW */}
      <section className="relative py-20 sm:py-28 overflow-hidden" style={{ background: 'var(--gradient-night)' }}>
        {/* Decorative Elements */}
        <div className="absolute inset-0 dot-pattern" style={{ opacity: 0.05 }}></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 opacity-20 blur-3xl animate-float" style={{ background: 'var(--saffron)' }}></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 opacity-20 blur-3xl animate-float" style={{ background: 'var(--terracotta)', animationDelay: '2s' }}></div>

        <div className="relative mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 text-center">
          <h2
            className="text-4xl sm:text-5xl lg:text-6xl font-black text-white mb-6 animate-fade-in-up"
            style={{ fontFamily: 'var(--font-playfair)' }}
          >
            Bereit für frische <span className="text-gradient-warm">Deals</span>?
          </h2>
          <p className="text-xl text-white/80 mb-10 max-w-2xl mx-auto animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
            Werde Teil unserer Community und verpasse nie wieder ein Angebot von deinem Lieblingsmarkt.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            <button
              className="btn-primary px-10 py-5 rounded-2xl font-bold text-lg shadow-2xl inline-flex items-center justify-center gap-3"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              Kostenlos registrieren
            </button>
            <button
              className="px-10 py-5 rounded-2xl font-bold text-lg border-2 border-white/30 text-white hover:bg-white/10 transition-all inline-flex items-center justify-center gap-3"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
              Für Shop-Besitzer
            </button>
          </div>

          {/* Stats Row */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
            {[
              { value: '50+', label: 'Partner-Shops' },
              { value: '10K+', label: 'Aktive Nutzer' },
              { value: '247', label: 'Angebote heute' },
              { value: '4.9★', label: 'Bewertung' }
            ].map((stat, idx) => (
              <div key={idx} className="glass-card p-6 hover-scale" style={{ background: 'rgba(255, 255, 255, 0.08)', border: '1px solid rgba(255, 255, 255, 0.15)' }}>
                <div className="text-3xl font-black text-white mb-1" style={{ fontFamily: 'var(--font-playfair)' }}>{stat.value}</div>
                <div className="text-sm text-white/70">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
